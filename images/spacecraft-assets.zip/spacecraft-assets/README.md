# Instructions for Deliverables:

1. First, check the designs for mobile and desktop.
2. Second, the font for the headlines can be found in Google Fonts: https://fonts.google.com/specimen/Audiowide
3. Brand colors:
   light gray: #a3a3a3;
   blue-violet: #6f6cd2;
   grayish-black: #3c0f38;
4. Here is a video you can use for the feature video: https://www.youtube.com/watch?v=YfCws6c6_Tw
5. Ensure nav links and buttons have hover effects so the user knows that those items are clickable. Use brand colors when and where possible for hover colors.

# Launch Image Gallery Section:

1. Under the Our Mission Section, create a section with a blue-violet background and a grayish-black button that says "Launch Image Gallery".

2. For the "Launch Image Gallery" section, ensure that when you click the button, you then see the section expand and fill up with the data found in the js/rocketdata.js file. Yes, this functionality will utilize your JS skills.

3. So when the user clicks the button, the section will expand to display all of the images in the collection in that JS file with the name of the rocket and the descriptions. You can style these how you would like.
