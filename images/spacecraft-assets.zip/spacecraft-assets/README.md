# Instructions for Deliverables:

1. First, check the designs for mobile and desktop.
2. Second, the font for the headlines can be found in Google Fonts: https://fonts.google.com/specimen/Audiowide. Same for the font for the body copy, which is Arial.
3. Brand colors:
   light gray: #a3a3a3;
   blue-violet: #6f6cd2;
   grayish-black/dark-purple: #3c0f38;
4. Here is a video you can use for the feature video: https://www.youtube.com/watch?v=YfCws6c6_Tw
5. Ensure nav links and buttons have hover effects so the user knows that those items are clickable. Use brand colors when and where possible for hover colors.

# Launch Image Gallery Section:

1. Under the Our Mission Section, create a section with a blue-violet background and a grayish-black button that says "Launch Image Gallery".

2. For the "Launch Image Gallery" section, ensure that when you click the button, you then see the section expand and fill up with the data found in the js/rocketdata.js file. Yes, this functionality will utilize your JS skills.

3. So when the user clicks the button, the section will expand to display all of the images in the collection in that JS file with the name of the rocket and the descriptions. You can style these how you would like.

# Reference

1. Feel free to refer to the our slides to recall how to insert jQuery into WordPress: https://anniecannons.github.io/ac-intro-wordpress/#/103

2. Remember that the jQuery documentation is available to search and research methods and event listeners https://api.jquery.com/

3. Bootstrap is already built into WordPress X Theme. Feel free to browse the Components section to find the best components for your data (mission, rocket, image, description). https://getbootstrap.com/

4. To practice displaying items that are in a collection to the user, you may find it helpful to use an online code sandbox (e.g., JS Bin) to troubleshoot the code first before copying and pasting into WordPress. https://jsbin.com/?html,css,js,output

5. When working in JS Bin, remember best practices for structuring code in JS. Variables are listed first. Functions are listed next. Finally, function executions are listed last. Feel free to refer to your jQuery Budget Exercise, if you have completed it, and apply lessons learned to structuring your code in WordPress.

6. Remember that WordPress may add extra spans, divs, etc. So check Dev Tools in the localhost site preview window to make sure you have the correct jQuery selector and thus the applicable jQuery methods to apply in Global and/or Content JS.
