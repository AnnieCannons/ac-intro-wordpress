var rocketData = [
  {
    mission: "10652",
    rocket: "Satellite 1",
    image:
      "https://www.nasa.gov/sites/default/files/styles/full_width_feature/public/thumbnails/image/westernhemisphere_geos_2019246_lrg.jpg",
    description:
      "Satellite Captures Four Tropical Cyclones from Space.On Sept. 4, 2019, a loose chain of tropical cyclones lined up across the Western Hemisphere.",
  },
  {
    mission: "10652",
    rocket: "International Space Station",
    image:
      "https://www.nasa.gov/sites/default/files/styles/full_width_feature/public/thumbnails/image/403c1251.jpg",
    description:
      "Hurricane Dorian Seen From Aboard the Space Station. NASA astronaut Christian Koch snapped this image of Hurricane Dorian as the International Space Station during a flyover on Monday, September 2, 2019.",
  },
  {
    mission: "43652",
    rocket: "ICESat-2 ",
    image:
      "https://www.nasa.gov/sites/default/files/styles/full_width_feature/public/thumbnails/image/29759342597_1acc62974d_o.jpg",
    description:
      "ICESat-2 Lifts Off to Study Earth's Changing Ice. A Delta II rocket launches with NASA's ICESat-2 onboard, Saturday, Sept. 15, 2018, from Vandenberg Air Force Base in California.",
  },
  {
    mission: "6547652",
    rocket: "Space Launch System",
    image:
      "https://www.nasa.gov/sites/default/files/styles/full_width_feature/public/thumbnails/image/0fd4113.jpg",
    description:
      "Structural Test Article for NASA’s Space Launch System.The fourth and final structural test article for NASA’s Space Launch System (SLS) core stage was unloaded from NASA’s barge Pegasus at NASA’s Marshall Space Flight Center in Huntsville, Alabama, Tuesday, July 9, 2019.",
  },
  {
    mission: "105436652",
    rocket: "Space Launch System",
    image:
      "https://www.nasa.gov/sites/default/files/styles/full_width_feature/public/thumbnails/image/block1_cargo_onml_fogsun_r1.jpg",
    description:
      "Daybreak on the Space Launch System. An illustration of the Block 1 cargo configuration for SLS positioned on the mobile launcher ahead of launch day. In place of NASA’s Orion spacecraft is a fairing designed to hold payloads needed to explore the Moon and beyond.",
  },
];

